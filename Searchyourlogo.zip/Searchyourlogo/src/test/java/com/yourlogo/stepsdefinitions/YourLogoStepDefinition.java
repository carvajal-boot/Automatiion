package com.yourlogo.stepsdefinitions;

import com.yourlogo.pageobject.YourLogoPage;
import com.yourlogo.steps.YourLogoSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class YourLogoStepDefinition {
	
	@Steps
	YourLogoSteps yourlogo;
	
	@Given("^Open page$")
	public void open_page() {
		
		yourlogo.OpenPage();
	   
	  
	}

}
