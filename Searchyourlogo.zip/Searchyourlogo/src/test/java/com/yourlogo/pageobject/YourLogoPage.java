package com.yourlogo.pageobject;

import org.openqa.selenium.WebDriver;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://automationpractice.com")

public class YourLogoPage extends PageObject{
	
	WebDriver driver;

	public YourLogoPage() {
	
	}
	
	public void OpenPage() {
		System.out.println("Exito");
	}
	
	

}
