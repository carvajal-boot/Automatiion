package com.yourlogo.steps;

import com.yourlogo.pageobject.YourLogoPage;

import net.thucydides.core.annotations.Step;

public class YourLogoSteps {
	
	YourLogoPage YourlogoSteps;
	
	
	@Step
	public void OpenPage() {
		
		YourlogoSteps.open();
		
	}

}
