package com.yourlogo.steps;

import com.yourlogo.pageobject.YourLogoPage;

import net.thucydides.core.annotations.Step;

public class YourLogoSteps {

	YourLogoPage YourlogoSteps;

	@Step
	public void openPage() {
		YourlogoSteps.open();
	}

	@Step
	public void clickSignIn() throws InterruptedException {
		YourlogoSteps.clickSignIn();
	}

	@Step
	public void signUsser(String usser) {
		YourlogoSteps.signUsser(usser);
	}

	@Step
	public void signPassword(int password) {
		YourlogoSteps.signPassword(password);
	}

	@Step
	public void clickcontinue() throws InterruptedException {
		YourlogoSteps.clickContinue();
	}

	@Step
	public void loginSuccessfull() {
		YourlogoSteps.loginSuccessfull();
	}

	@Step
	public void SearchOnThePage(String article,int quantity, String size, String color) throws InterruptedException {
		YourlogoSteps.SearchOnThePage(article, quantity, size, color);
	}
	
	@Step
	public void validatePageChekout() throws InterruptedException {
		YourlogoSteps.validatePageChekout();
	}
	
	@Step
	public void enterTheMessageOfYourProduct() throws InterruptedException {
		YourlogoSteps.enterTheMessageOfYourProduct();
	}
	
	@Step
	public void selectMyMethodOfPay() throws InterruptedException {
		YourlogoSteps.selectMyMethodOfPay();
	}
	
	@Step
	public void checkThatMyOrdenOnMyStoreIsComplete() throws InterruptedException {
		YourlogoSteps.checkThatMyOrdenOnMyStoreIsComplete();
	}

}
