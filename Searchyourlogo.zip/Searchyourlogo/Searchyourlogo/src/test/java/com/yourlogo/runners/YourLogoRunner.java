package com.yourlogo.runners;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.runner.RunWith;

import com.yourlogo.base.BeforeSuite;
import com.yourlogo.base.DataToFeature;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;

@RunWith(RunnerPersonalizado.class)

@CucumberOptions(features = "src/test/resources/features/yourlogo.feature", glue = {
		"com.yourlogo.stepsdefinitions" }, snippets = SnippetType.CAMELCASE, tags = "@Chech_Yourlogo")

public class YourLogoRunner {
	@BeforeSuite
	public static void test() throws InvalidFormatException, IOException {
		DataToFeature.overrideFeatureFiles(".\\src\\test\\resources\\features\\yourlogo.feature");
	}

}
