package com.yourlogo.pageobject;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.WhenPageOpens;

@DefaultUrl("http://automationpractice.com")

public class YourLogoPage extends PageObject {

//	public static WebDriver driver;

	String signIn = "//a[@class='login']";
	String namevalidation = "//a[@class='account']//*[contains(.,'Camilo Carvajal')]";
	String imagenewexperience = "//img[@class='logo img-responsive']";
	String upbuton = "//a[@class='btn btn-default button-plus product_quantity_up']";
	String list = "(//div[@class='attribute_list'])[1]";
	String selectlist = "(//div[@class='attribute_list']//span[contains(.,'L')])[1]";
	String checkout = "//a[@class='btn btn-default button button-medium']";
	String validatepage = "//h1[@id='cart_title']";
	String checkouttwo = "//a[@title='Proceed to checkout' and @class='button btn btn-default standard-checkout button-medium']";
	String methodpay = "//a[@class='bankwire']";
	String checkfinish = "//button[@class='button btn btn-default button-medium']";

	@WhenPageOpens
	public void maximisewindow() {
		getDriver().manage().window().maximize();
	}

	public void clickSignIn() throws InterruptedException {
		find(By.xpath(signIn)).click();
		Thread.sleep(3000);
	}

	public void signUsser(String usser) {
		find(By.id("email")).sendKeys(usser);
	}

	public void signPassword(int password) {
		find(By.id("passwd")).sendKeys("" + password);
	}

	public void clickContinue() throws InterruptedException {
		find(By.id("SubmitLogin")).click();
		Thread.sleep(5000);
	}

	public void loginSuccessfull() {
		String textlogin = find(By.xpath(namevalidation)).getText();
		assertEquals(textlogin, "Camilo Carvajal");
	}
	@Screenshots(forEachAction=true)
	public void SearchOnThePage(String article,int quantity, String size, String color) throws InterruptedException {
		
		find(By.xpath(imagenewexperience)).click();
		Thread.sleep(2000);
		WebElement element = find(By.xpath("(//a[@class='product_img_link' and @title='" + article+ "']//img[@class='replace-2x img-responsive'])[1]"));
		JavascriptExecutor jse = (JavascriptExecutor) getDriver();
		jse.executeScript("arguments[0].scrollIntoView()", element);
		Thread.sleep(5000);
		find(By.xpath("(//div[@class='left-block']//a[@href='http://automationpractice.com/index.php?id_product=2&controller=product' and @class='product_img_link' and @title='"+ article + "'])[1]")).click();
		Thread.sleep(10000);
		getDriver().switchTo().frame(1);
		find(By.id("quantity_wanted")).clear();
		find(By.id("quantity_wanted")).sendKeys("" + quantity);
		find(By.xpath(list)).click();
		Thread.sleep(1000);
		find(By.xpath("(//div[@class='attribute_list']//option[@title='"+size+"'])[1]")).click();
		Thread.sleep(1000);
		find(By.name(color)).click();
		find(By.id("add_to_cart")).click();
		Thread.sleep(1000);
		find(By.xpath(checkout)).click();
		Thread.sleep(3000);
	}
	
	 public void validatePageChekout() throws InterruptedException {
		 getDriver().switchTo().defaultContent();
		 
		 if(find(By.xpath(validatepage)).isVisible()) {			 
			 System.out.println("DEBUG: Is this the page of resume");			 
		 }else {
			 throw new RuntimeException(
					 "ERROR: Page no found"
					 );	 
		 }
		 find(By.xpath(checkouttwo)).click();
		 Thread.sleep(5000);

	 }
	 
	 public void enterTheMessageOfYourProduct() throws InterruptedException {
		   find(By.name("message")).click();
		   find(By.name("message")).sendKeys("Please attachment my facture");
		   Thread.sleep(2000);
		   find(By.name("processAddress")).click();
		   Thread.sleep(3000);
		   find(By.id("cgv")).click();
		   find(By.name("processCarrier")).click();
		   Thread.sleep(3000);
		    
		}


	
	 public void selectMyMethodOfPay() throws InterruptedException {
		 	find(By.xpath(methodpay)).click();
		 	Thread.sleep(3000);
		
		}

		
	 public void checkThatMyOrdenOnMyStoreIsComplete() throws InterruptedException {
		 	find(By.xpath(checkfinish)).click();
		 	Thread.sleep(3000);
		 	String orderfinish = find(By.xpath("//p[@class='cheque-indent']//strong[@class='dark']")).getText();
		 	assertEquals(orderfinish, "Your order on My Store is complete.");
		 	Thread.sleep(3000);
		}

}
