package com.yourlogo.stepsdefinitions;

import com.yourlogo.steps.YourLogoSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class YourLogoDefinition {

	@Steps
	YourLogoSteps yourlogo;

	@Given("^Open the page of automation practice$")
	public void open_page() throws InterruptedException {
		yourlogo.openPage();
	}

	@When("^SingIn the usser (.*)$")
	public void singin_the_usser(String usser) throws InterruptedException {
		yourlogo.clickSignIn();
		yourlogo.signUsser(usser);

	}

	@When("^SignIn the password (\\d+)$")
	public void signinThePassword(int password) throws InterruptedException {
		yourlogo.signPassword(password);
		yourlogo.clickcontinue();
	}

	@Then("^My login is successfull$")
	public void my_login_is_successfull() {
		yourlogo.loginSuccessfull();

	}

	@When("^Perform a search on the page (.*) (\\d+) (.*) (.*)$")
	public void performASearchOnThePage(String article, int quantity, String size, String color)
			throws InterruptedException {
		yourlogo.SearchOnThePage(article, quantity, size, color);
	}

	@And("^Validate page of products$")
	public void validate_Page_of_products() throws InterruptedException {
		yourlogo.validatePageChekout();
	}

	@When("^Enter the message of your product$")
	public void enterTheMessageOfYourProduct() throws InterruptedException {
		yourlogo.enterTheMessageOfYourProduct();
	}

	@When("^Select my method of pay$")
	public void selectMyMethodOfPay() throws InterruptedException {
		yourlogo.selectMyMethodOfPay();
	}

	@Then("^Check that my orden on my store is complete$")
	public void checkThatMyOrdenOnMyStoreIsComplete() throws InterruptedException {
		yourlogo.checkThatMyOrdenOnMyStoreIsComplete();

	}

}
