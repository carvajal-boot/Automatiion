package com.yourlogo.main;

import org.junit.Test;
import org.junit.runner.JUnitCore;

import com.yourlogo.runners.YourLogoRunner;

public class Main {
	@Test
	public void test() {
		JUnitCore junit = new JUnitCore();
		junit.run(YourLogoRunner.class);
	}

	public static void main(String[] args) {
		Main main = new Main();
		main.test();
	}

}
